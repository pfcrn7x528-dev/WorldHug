'use client';

import { useState, useEffect } from 'react';

export default function EventsPage() {
  const [events, setEvents] = useState([]);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [participantId, setParticipantId] = useState(null);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    location: '',
    event_date: ''
  });

  useEffect(() => {
    const storedId = localStorage.getItem('participantId');
    if (storedId) {
      setParticipantId(storedId);
    }
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    try {
      const response = await fetch('/api/events');
      if (!response.ok) throw new Error('Failed to fetch events');
      const data = await response.json();
      setEvents(data.events);
    } catch (err) {
      console.error(err);
      setError(err.message);
    }
  };

  const handleCreateEvent = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...formData,
          organizer_id: participantId
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to create event');
      }

      setFormData({ title: '', description: '', location: '', event_date: '' });
      setShowCreateForm(false);
      await fetchEvents();
    } catch (err) {
      console.error(err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleJoinEvent = async (eventId) => {
    if (!participantId) {
      alert('Please join the chain first to participate in events');
      return;
    }

    try {
      const response = await fetch(`/api/events/${eventId}/join`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ participant_id: participantId })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Failed to join event');
      }

      await fetchEvents();
      alert('Successfully joined the event!');
    } catch (err) {
      console.error(err);
      alert(err.message);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#E8F4F8] to-white">
      {/* Header */}
      <header className="bg-white border-b border-[#D4E8F0] py-6">
        <div className="max-w-6xl mx-auto px-4">
          <h1 className="text-4xl md:text-5xl font-bold text-[#2C5F7C] text-center font-serif">
            The World Hug
          </h1>
          <p className="text-center text-[#5A8FA8] mt-2 text-lg italic">
            Peace Events Worldwide
          </p>
        </div>
      </header>

      {/* Navigation */}
      <nav className="bg-white border-b border-[#D4E8F0] py-3">
        <div className="max-w-6xl mx-auto px-4 flex flex-wrap justify-center gap-4">
          <a href="/" className="text-[#2C5F7C] hover:text-[#5A8FA8] px-4 py-2 rounded-lg hover:bg-[#E8F4F8] font-medium">
            Home
          </a>
          <a href="/map" className="text-[#2C5F7C] hover:text-[#5A8FA8] px-4 py-2 rounded-lg hover:bg-[#E8F4F8] font-medium">
            Global Map
          </a>
          <a href="/chat" className="text-[#2C5F7C] hover:text-[#5A8FA8] px-4 py-2 rounded-lg hover:bg-[#E8F4F8] font-medium">
            Chat
          </a>
          <a href="/events" className="text-[#2C5F7C] hover:text-[#5A8FA8] px-4 py-2 rounded-lg bg-[#E8F4F8] font-medium">
            Events
          </a>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Create Event Button */}
        <div className="mb-8 flex justify-between items-center">
          <h2 className="text-3xl font-bold text-[#2C5F7C]">
            Upcoming Peace Events
          </h2>
          {participantId && (
            <button
              onClick={() => setShowCreateForm(!showCreateForm)}
              className="px-6 py-3 bg-[#2C5F7C] text-white font-medium rounded-lg hover:bg-[#5A8FA8] transition-colors"
            >
              {showCreateForm ? 'Cancel' : '+ Create Event'}
            </button>
          )}
        </div>

        {!participantId && (
          <div className="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-lg mb-6">
            <a href="/" className="underline font-medium">Join the chain</a> to create and participate in events
          </div>
        )}

        {/* Create Event Form */}
        {showCreateForm && (
          <div className="bg-white rounded-2xl shadow-lg p-8 border border-[#D4E8F0] mb-8">
            <h3 className="text-2xl font-bold text-[#2C5F7C] mb-6">
              Create a Peace Event
            </h3>

            {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-6">
                {error}
              </div>
            )}

            <form onSubmit={handleCreateEvent} className="space-y-6">
              <div>
                <label className="block text-[#2C5F7C] font-medium mb-2">
                  Event Title *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-[#D4E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5A8FA8]"
                  placeholder="e.g., Peace March in Central Park"
                />
              </div>

              <div>
                <label className="block text-[#2C5F7C] font-medium mb-2">
                  Description
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleChange}
                  rows={4}
                  className="w-full px-4 py-3 border border-[#D4E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5A8FA8]"
                  placeholder="Describe your event..."
                />
              </div>

              <div>
                <label className="block text-[#2C5F7C] font-medium mb-2">
                  Location *
                </label>
                <input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-[#D4E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5A8FA8]"
                  placeholder="City, Country"
                />
              </div>

              <div>
                <label className="block text-[#2C5F7C] font-medium mb-2">
                  Event Date & Time *
                </label>
                <input
                  type="datetime-local"
                  name="event_date"
                  value={formData.event_date}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-[#D4E8F0] rounded-lg focus:outline-none focus:ring-2 focus:ring-[#5A8FA8]"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-[#2C5F7C] text-white font-bold py-4 px-6 rounded-lg hover:bg-[#5A8FA8] transition-colors disabled:bg-gray-400 text-lg"
              >
                {loading ? 'Creating Event...' : 'Create Event'}
              </button>
            </form>
          </div>
        )}

        {/* Events List */}
        <div className="space-y-6">
          {events.length === 0 && (
            <div className="bg-white rounded-2xl shadow-lg p-12 border border-[#D4E8F0] text-center">
              <p className="text-[#5A8FA8] text-lg">
                No events scheduled yet. Be the first to create a peace event!
              </p>
            </div>
          )}

          {events.map((event) => (
            <div
              key={event.id}
              className="bg-white rounded-2xl shadow-lg p-6 border border-[#D4E8F0] hover:shadow-xl transition-shadow"
            >
              <div className="flex flex-col md:flex-row md:items-start md:justify-between">
                <div className="flex-1">
                  <h3 className="text-2xl font-bold text-[#2C5F7C] mb-2">
                    {event.title}
                  </h3>
                  
                  <div className="space-y-2 mb-4">
                    <p className="text-[#5A8FA8] flex items-center gap-2">
                      <span className="font-medium">📍</span>
                      {event.location}
                    </p>
                    <p className="text-[#5A8FA8] flex items-center gap-2">
                      <span className="font-medium">📅</span>
                      {new Date(event.event_date).toLocaleString()}
                    </p>
                    <p className="text-[#5A8FA8] flex items-center gap-2">
                      <span className="font-medium">👤</span>
                      Organized by {event.organizer_name || 'Anonymous'}
                      {event.organizer_country && ` (${event.organizer_country})`}
                    </p>
                    <p className="text-[#5A8FA8] flex items-center gap-2">
                      <span className="font-medium">👥</span>
                      {event.participant_count} participants
                    </p>
                  </div>

                  {event.description && (
                    <p className="text-gray-700 mt-4">
                      {event.description}
                    </p>
                  )}
                </div>

                <div className="mt-4 md:mt-0 md:ml-6">
                  <button
                    onClick={() => handleJoinEvent(event.id)}
                    disabled={!participantId}
                    className="px-6 py-3 bg-[#2C5F7C] text-white font-medium rounded-lg hover:bg-[#5A8FA8] transition-colors disabled:bg-gray-400 whitespace-nowrap"
                  >
                    Join Event
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t border-[#D4E8F0] py-8 mt-20">
        <div className="max-w-6xl mx-auto px-4 text-center text-[#5A8FA8]">
          <p className="font-medium">The World Hug</p>
          <p className="text-sm mt-2">Peace circles the globe faster than conflict</p>
        </div>
      </footer>
    </div>
  );
}
