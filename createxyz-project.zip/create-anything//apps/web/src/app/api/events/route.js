import sql from "@/app/api/utils/sql";

// GET all events
export async function GET(request) {
  try {
    const { searchParams } = new URL(request.url);
    const country = searchParams.get('country');
    
    let events;
    
    if (country) {
      events = await sql`
        SELECT 
          e.*,
          p.name as organizer_name,
          COUNT(DISTINCT ep.participant_id) as participant_count
        FROM events e
        LEFT JOIN participants p ON e.organizer_id = p.id
        LEFT JOIN event_participants ep ON e.id = ep.event_id
        WHERE p.country = ${country}
        GROUP BY e.id, p.name
        ORDER BY e.event_date ASC
      `;
    } else {
      events = await sql`
        SELECT 
          e.*,
          p.name as organizer_name,
          p.country as organizer_country,
          COUNT(DISTINCT ep.participant_id) as participant_count
        FROM events e
        LEFT JOIN participants p ON e.organizer_id = p.id
        LEFT JOIN event_participants ep ON e.id = ep.event_id
        GROUP BY e.id, p.name, p.country
        ORDER BY e.event_date ASC
      `;
    }
    
    return Response.json({ events });
  } catch (error) {
    console.error('Error fetching events:', error);
    return Response.json({ error: 'Failed to fetch events' }, { status: 500 });
  }
}

// POST - Create new event
export async function POST(request) {
  try {
    const body = await request.json();
    const { title, description, location, latitude, longitude, event_date, organizer_id } = body;
    
    // Validation
    if (!title || !location || !event_date) {
      return Response.json({ error: 'Title, location, and event date are required' }, { status: 400 });
    }
    
    // Insert new event
    const [event] = await sql`
      INSERT INTO events (
        title, description, location, latitude, longitude, 
        event_date, organizer_id
      )
      VALUES (
        ${title}, ${description || null}, ${location}, 
        ${latitude || null}, ${longitude || null}, 
        ${event_date}, ${organizer_id || null}
      )
      RETURNING *
    `;
    
    return Response.json({ event }, { status: 201 });
  } catch (error) {
    console.error('Error creating event:', error);
    return Response.json({ error: 'Failed to create event' }, { status: 500 });
  }
}
