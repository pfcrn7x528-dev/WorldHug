import sql from "@/app/api/utils/sql";

// GET chain statistics
export async function GET(request) {
  try {
    // Earth's circumference in km
    const EARTH_CIRCUMFERENCE = 40075;
    
    // Get total participants
    const [stats] = await sql`
      SELECT 
        COUNT(*) as total_participants,
        COUNT(DISTINCT country) as countries_reached
      FROM participants
    `;
    
    // Get participants with coordinates
    const [coordStats] = await sql`
      SELECT COUNT(*) as participants_with_coords
      FROM participants
      WHERE latitude IS NOT NULL AND longitude IS NOT NULL
    `;
    
    // Calculate approximate distance covered
    // Assuming average distance between participants is ~100km
    const avgDistancePerLink = 100;
    const totalDistance = stats.total_participants * avgDistancePerLink;
    const percentageOfEarth = (totalDistance / EARTH_CIRCUMFERENCE) * 100;
    
    return Response.json({
      totalParticipants: parseInt(stats.total_participants),
      countriesReached: parseInt(stats.countries_reached),
      participantsWithCoords: parseInt(coordStats.participants_with_coords),
      estimatedDistance: Math.round(totalDistance),
      percentageOfEarth: Math.min(percentageOfEarth, 100).toFixed(2)
    });
  } catch (error) {
    console.error('Error fetching stats:', error);
    return Response.json({ error: 'Failed to fetch stats' }, { status: 500 });
  }
}
