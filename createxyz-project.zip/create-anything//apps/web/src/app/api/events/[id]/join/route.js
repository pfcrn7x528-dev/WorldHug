import sql from "@/app/api/utils/sql";

// POST - Join an event
export async function POST(request, { params }) {
  try {
    const { id } = params;
    const body = await request.json();
    const { participant_id } = body;
    
    // Validation
    if (!participant_id) {
      return Response.json({ error: 'Participant ID is required' }, { status: 400 });
    }
    
    // Check if already joined
    const [existing] = await sql`
      SELECT * FROM event_participants 
      WHERE event_id = ${id} AND participant_id = ${participant_id}
    `;
    
    if (existing) {
      return Response.json({ error: 'Already joined this event' }, { status: 400 });
    }
    
    // Join event
    const [eventParticipant] = await sql`
      INSERT INTO event_participants (event_id, participant_id)
      VALUES (${id}, ${participant_id})
      RETURNING *
    `;
    
    return Response.json({ eventParticipant }, { status: 201 });
  } catch (error) {
    console.error('Error joining event:', error);
    return Response.json({ error: 'Failed to join event' }, { status: 500 });
  }
}
